<?php
/**
 * LearnDash Settings Section for PayPal Metabox.
 *
 * @since 2.4.0
 * @deprecated 3.6.0
 * @package LearnDash\Settings\Sections
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

_deprecated_file( basename( __FILE__ ), '3.6.0', 'includes/settings/settings-sections/settings-sections-payments/class-ld-settings-section-paypal.php' );
