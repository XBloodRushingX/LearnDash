<?php
/**
 * LearnDash Settings Page Data Upgrades.
 *
 * @since 2.6.0
 * @deprecated 3.6.0
 * @package LearnDash\Settings\Pages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

_deprecated_file( basename( __FILE__ ), '3.6.0' );
