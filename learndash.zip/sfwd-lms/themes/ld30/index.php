<?php
/**
 * LearnDash ld30 template init.
 *
 * @package LearnDash\Templates\LD30
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/includes/class-ld-themes-register.php';
require_once __DIR__ . '/includes/class-ld-settings-section-theme-ld30.php';
